<?php

require_once 'Fpdf/fpdf.php';
require_once '../web_db/connection.php';
class PDF extends FPDF {

// Load data
    function LoadData() {
        // Read file lines

        $database=new dbconnection();
        $db = $database->openconnection();        $sql = "select * from profile  ";
   // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
        $this->Cell(120, 7,'HEPATITIS CONTROL', 0, 0, 'L');
        $this->Cell(60, 7, 'DISTRICT: NYARUGENGE', 0, 0, 'L');
        $this->Ln();
        $this->Cell(120, 7, 'RWANDA ', 0, 0, 'E');
        $this->Cell(60, 7, 'TELEPHONE: . ', 0, 0, 'L');

        $this->Ln();
        $this->Ln();
        $this->Ln();
        $this->Ln();
        $this->SetFont("Arial", 'B', 14);
        $this->Cell(170, 7, 'profile REPORT ', 0, 0, 'C');

        $this->Ln();
        $this->Ln();
        $this->SetFont("Arial", '', 14);
// </editor-fold>

$this->Cell(30, 7, 'profile_id', 1, 0, 'L');$this->Cell(30, 7, 'image', 1, 0, 'L');$this->Cell(30, 7, 'dob', 1, 0, 'L');$this->Cell(30, 7, 'name', 1, 0, 'L');$this->Cell(30, 7, 'last_name', 1, 0, 'L');$this->Cell(30, 7, 'gender', 1, 0, 'L');$this->Cell(30, 7, 'telephone_number', 1, 0, 'L');$this->Cell(30, 7, 'email', 1, 0, 'L');$this->Cell(30, 7, 'residence', 1, 0, 'L');
 $this->Ln();
        foreach ($db->query($sql) as $row) {
$this->cell(30, 7, $row['profile_id'], 1, 0, 'L');
$this->cell(30, 7, $row['image'], 1, 0, 'L');
$this->cell(30, 7, $row['dob'], 1, 0, 'L');
$this->cell(30, 7, $row['name'], 1, 0, 'L');
$this->cell(30, 7, $row['last_name'], 1, 0, 'L');
$this->cell(30, 7, $row['gender'], 1, 0, 'L');
$this->cell(30, 7, $row['telephone_number'], 1, 0, 'L');
$this->cell(30, 7, $row['email'], 1, 0, 'L');
$this->cell(30, 7, $row['residence'], 1, 0, 'L');


 $this->Ln();
        }
    }
}

$pdf = new PDF();
$pdf->SetFont('Arial', '', 13);
$pdf->AddPage();
$pdf->LoadData();
$pdf->Output(); 
