<?php
 require_once '../web_db/connection.php'; 
class multi_values{


function list_account($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from account";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> account </td>
<td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['account_id']; ?>
</td>
<td class="account_category_id_cols account " title="account" >
<?php echo  $this->_e($row['account_category']); ?>
</td>
<td>
<?php echo  $this->_e($row['date_created']); ?>
</td>
<td>
<?php echo  $this->_e($row['profile']); ?>
</td>
<td>
<?php echo  $this->_e($row['username']); ?>
</td>
<td>
<?php echo  $this->_e($row['password']); ?>
</td>
<td>
<?php echo  $this->_e($row['is_online']); ?>
</td>


<td>
                        <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="account_id"  data-table="
                           <?php echo $row['account_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="account_update_link" style="color: #000080;" value="
                           <?php echo $row['account_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_account_account_category($id) {
        
        $db = new dbconnection();
        $sql = "select   account.account_category from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account_category'];
        echo $field;
    } function get_chosen_account_date_created($id) {
        
        $db = new dbconnection();
        $sql = "select   account.date_created from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date_created'];
        echo $field;
    } function get_chosen_account_profile($id) {
        
        $db = new dbconnection();
        $sql = "select   account.profile from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    } function get_chosen_account_username($id) {
        
        $db = new dbconnection();
        $sql = "select   account.username from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['username'];
        echo $field;
    } function get_chosen_account_password($id) {
        
        $db = new dbconnection();
        $sql = "select   account.password from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['password'];
        echo $field;
    } function get_chosen_account_is_online($id) {
        
        $db = new dbconnection();
        $sql = "select   account.is_online from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['is_online'];
        echo $field;
    }

 function All_account() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  account_id   from account";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_account() {
        $con = new dbconnection();
        $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }
 function get_last_account() {
        $con = new dbconnection();
        $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }
function list_account_category($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from account_category";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> account_category </td>
<td>  </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['account_category_id']; ?>
</td>
<td class="name_id_cols account_category " title="account_category" >
<?php echo  $this->_e($row['name']); ?>
</td>


<td>
                        <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="account_category_id"  data-table="
                           <?php echo $row['account_category_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="account_category_update_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_account_category_name($id) {
        
        $db = new dbconnection();
        $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_category_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

 function All_account_category() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  account_category_id   from account_category";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_account_category() {
        $con = new dbconnection();
        $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_category_id'];
        return $first_rec;
    }
 function get_last_account_category() {
        $con = new dbconnection();
        $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_category_id'];
        return $first_rec;
    }
function list_profile($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from profile";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> profile </td>
<td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['profile_id']; ?>
</td>
<td class="dob_id_cols profile " title="profile" >
<?php echo  $this->_e($row['dob']); ?>
</td>
<td>
<?php echo  $this->_e($row['name']); ?>
</td>
<td>
<?php echo  $this->_e($row['last_name']); ?>
</td>
<td>
<?php echo  $this->_e($row['gender']); ?>
</td>
<td>
<?php echo  $this->_e($row['telephone_number']); ?>
</td>
<td>
<?php echo  $this->_e($row['email']); ?>
</td>
<td>
<?php echo  $this->_e($row['residence']); ?>
</td>
<td>
<?php echo  $this->_e($row['image']); ?>
</td>


<td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="profile_id"  data-table="
                           <?php echo $row['profile_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="profile_update_link" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_profile_dob($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.dob from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['dob'];
        echo $field;
    } function get_chosen_profile_name($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    } function get_chosen_profile_last_name($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['last_name'];
        echo $field;
    } function get_chosen_profile_gender($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.gender from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['gender'];
        echo $field;
    } function get_chosen_profile_telephone_number($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['telephone_number'];
        echo $field;
    } function get_chosen_profile_email($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.email from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['email'];
        echo $field;
    } function get_chosen_profile_residence($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.residence from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['residence'];
        echo $field;
    } function get_chosen_profile_image($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.image from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['image'];
        echo $field;
    }

 function All_profile() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  profile_id   from profile";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }
 function get_last_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }
function list_image($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from image";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> image </td>
<td>  </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['image_id']; ?>
</td>
<td class="path_id_cols image " title="image" >
<?php echo  $this->_e($row['path']); ?>
</td>


<td>
                        <a href="#" class="image_delete_link" style="color: #000080;" data-id_delete="image_id"  data-table="
                           <?php echo $row['image_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="image_update_link" style="color: #000080;" value="
                           <?php echo $row['image_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_image_path($id) {
        
        $db = new dbconnection();
        $sql = "select   image.path from image where image_id=:image_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':image_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['path'];
        echo $field;
    }

 function All_image() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  image_id   from image";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_image() {
        $con = new dbconnection();
        $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['image_id'];
        return $first_rec;
    }
 function get_last_image() {
        $con = new dbconnection();
        $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['image_id'];
        return $first_rec;
    }
function list_province($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from province";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> province </td>

<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['province_id']; ?>
</td>


<td>
                        <a href="#" class="province_delete_link" style="color: #000080;" data-id_delete="province_id"  data-table="
                           <?php echo $row['province_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="province_update_link" style="color: #000080;" value="
                           <?php echo $row['province_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field


 function All_province() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  province_id   from province";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_province() {
        $con = new dbconnection();
        $sql = "select province.province_id from province
                    order by province.province_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['province_id'];
        return $first_rec;
    }
 function get_last_province() {
        $con = new dbconnection();
        $sql = "select province.province_id from province
                    order by province.province_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['province_id'];
        return $first_rec;
    }
function list_district($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from district";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> district </td>
<td>  </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['district_id']; ?>
</td>
<td class="province_id_cols district " title="district" >
<?php echo  $this->_e($row['province']); ?>
</td>


<td>
                        <a href="#" class="district_delete_link" style="color: #000080;" data-id_delete="district_id"  data-table="
                           <?php echo $row['district_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="district_update_link" style="color: #000080;" value="
                           <?php echo $row['district_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_district_province($id) {
        
        $db = new dbconnection();
        $sql = "select   district.province from district where district_id=:district_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':district_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['province'];
        echo $field;
    }

 function All_district() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  district_id   from district";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_district() {
        $con = new dbconnection();
        $sql = "select district.district_id from district
                    order by district.district_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['district_id'];
        return $first_rec;
    }
 function get_last_district() {
        $con = new dbconnection();
        $sql = "select district.district_id from district
                    order by district.district_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['district_id'];
        return $first_rec;
    }
function list_Hospital($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from Hospital";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> Hospital </td>
<td> district </td><td> Name </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['Hospital_id']; ?>
</td>
<td class="district_id_cols Hospital " title="Hospital" >
<?php echo  $this->_e($row['district']); ?>
</td>
<td>
<?php echo  $this->_e($row['name']); ?>
</td>


<td>
                        <a href="#" class="Hospital_delete_link" style="color: #000080;" data-id_delete="Hospital_id"  data-table="
                           <?php echo $row['Hospital_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="Hospital_update_link" style="color: #000080;" value="
                           <?php echo $row['Hospital_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_Hospital_district($id) {
        
        $db = new dbconnection();
        $sql = "select   Hospital.district from Hospital where Hospital_id=:Hospital_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':Hospital_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['district'];
        echo $field;
    } function get_chosen_Hospital_name($id) {
        
        $db = new dbconnection();
        $sql = "select   Hospital.name from Hospital where Hospital_id=:Hospital_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':Hospital_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

 function All_Hospital() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  Hospital_id   from Hospital";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_Hospital() {
        $con = new dbconnection();
        $sql = "select Hospital.Hospital_id from Hospital
                    order by Hospital.Hospital_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['Hospital_id'];
        return $first_rec;
    }
 function get_last_Hospital() {
        $con = new dbconnection();
        $sql = "select Hospital.Hospital_id from Hospital
                    order by Hospital.Hospital_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['Hospital_id'];
        return $first_rec;
    }
function list_hospital_users($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from hospital_users";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> hospital_users </td>
<td> Hospital </td><td> Account </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['hospital_users_id']; ?>
</td>
<td class="hospital_id_cols hospital_users " title="hospital_users" >
<?php echo  $this->_e($row['hospital']); ?>
</td>
<td>
<?php echo  $this->_e($row['account']); ?>
</td>


<td>
                        <a href="#" class="hospital_users_delete_link" style="color: #000080;" data-id_delete="hospital_users_id"  data-table="
                           <?php echo $row['hospital_users_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="hospital_users_update_link" style="color: #000080;" value="
                           <?php echo $row['hospital_users_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_hospital_users_hospital($id) {
        
        $db = new dbconnection();
        $sql = "select   hospital_users.hospital from hospital_users where hospital_users_id=:hospital_users_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':hospital_users_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['hospital'];
        echo $field;
    } function get_chosen_hospital_users_account($id) {
        
        $db = new dbconnection();
        $sql = "select   hospital_users.account from hospital_users where hospital_users_id=:hospital_users_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':hospital_users_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

 function All_hospital_users() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  hospital_users_id   from hospital_users";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_hospital_users() {
        $con = new dbconnection();
        $sql = "select hospital_users.hospital_users_id from hospital_users
                    order by hospital_users.hospital_users_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['hospital_users_id'];
        return $first_rec;
    }
 function get_last_hospital_users() {
        $con = new dbconnection();
        $sql = "select hospital_users.hospital_users_id from hospital_users
                    order by hospital_users.hospital_users_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['hospital_users_id'];
        return $first_rec;
    }
function list_patient($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from patient";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> patient </td>
<td> Account </td><td> Insurance </td><td> Description </td><td> Entry Date </td><td> User </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['patient_id']; ?>
</td>
<td class="account_id_cols patient " title="patient" >
<?php echo  $this->_e($row['account']); ?>
</td>
<td>
<?php echo  $this->_e($row['insurance']); ?>
</td>
<td>
<?php echo  $this->_e($row['description']); ?>
</td>
<td>
<?php echo  $this->_e($row['entry_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['User']); ?>
</td>


<td>
                        <a href="#" class="patient_delete_link" style="color: #000080;" data-id_delete="patient_id"  data-table="
                           <?php echo $row['patient_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="patient_update_link" style="color: #000080;" value="
                           <?php echo $row['patient_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_patient_account($id) {
        
        $db = new dbconnection();
        $sql = "select   patient.account from patient where patient_id=:patient_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':patient_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    } function get_chosen_patient_insurance($id) {
        
        $db = new dbconnection();
        $sql = "select   patient.insurance from patient where patient_id=:patient_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':patient_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['insurance'];
        echo $field;
    } function get_chosen_patient_description($id) {
        
        $db = new dbconnection();
        $sql = "select   patient.description from patient where patient_id=:patient_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':patient_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['description'];
        echo $field;
    } function get_chosen_patient_entry_date($id) {
        
        $db = new dbconnection();
        $sql = "select   patient.entry_date from patient where patient_id=:patient_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':patient_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    } function get_chosen_patient_User($id) {
        
        $db = new dbconnection();
        $sql = "select   patient.User from patient where patient_id=:patient_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':patient_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    }

 function All_patient() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  patient_id   from patient";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_patient() {
        $con = new dbconnection();
        $sql = "select patient.patient_id from patient
                    order by patient.patient_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['patient_id'];
        return $first_rec;
    }
 function get_last_patient() {
        $con = new dbconnection();
        $sql = "select patient.patient_id from patient
                    order by patient.patient_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['patient_id'];
        return $first_rec;
    }
function list_Treatment($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from Treatment";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> Treatment </td>
<td> Hospital </td><td> Patient </td><td> Entry Date </td><td> User </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['Treatment_id']; ?>
</td>
<td class="hospital_id_cols Treatment " title="Treatment" >
<?php echo  $this->_e($row['hospital']); ?>
</td>
<td>
<?php echo  $this->_e($row['patient']); ?>
</td>
<td>
<?php echo  $this->_e($row['entry_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['User']); ?>
</td>


<td>
                        <a href="#" class="Treatment_delete_link" style="color: #000080;" data-id_delete="Treatment_id"  data-table="
                           <?php echo $row['Treatment_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="Treatment_update_link" style="color: #000080;" value="
                           <?php echo $row['Treatment_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_Treatment_hospital($id) {
        
        $db = new dbconnection();
        $sql = "select   Treatment.hospital from Treatment where Treatment_id=:Treatment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':Treatment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['hospital'];
        echo $field;
    } function get_chosen_Treatment_patient($id) {
        
        $db = new dbconnection();
        $sql = "select   Treatment.patient from Treatment where Treatment_id=:Treatment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':Treatment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['patient'];
        echo $field;
    } function get_chosen_Treatment_entry_date($id) {
        
        $db = new dbconnection();
        $sql = "select   Treatment.entry_date from Treatment where Treatment_id=:Treatment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':Treatment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    } function get_chosen_Treatment_User($id) {
        
        $db = new dbconnection();
        $sql = "select   Treatment.User from Treatment where Treatment_id=:Treatment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':Treatment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    }

 function All_Treatment() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  Treatment_id   from Treatment";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_Treatment() {
        $con = new dbconnection();
        $sql = "select Treatment.Treatment_id from Treatment
                    order by Treatment.Treatment_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['Treatment_id'];
        return $first_rec;
    }
 function get_last_Treatment() {
        $con = new dbconnection();
        $sql = "select Treatment.Treatment_id from Treatment
                    order by Treatment.Treatment_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['Treatment_id'];
        return $first_rec;
    }
 function get_account_category_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account_category.account_category_id,   account_category.name from account_category";
        ?>
        <select class="textbox cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_image_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_province_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select province.province_id,   province.name from province";
        ?>
        <select class="textbox cbo_province"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['province_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_district_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select district.district_id,   district.name from district";
        ?>
        <select class="textbox cbo_district"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['district_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_hospital_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select hospital.hospital_id,   hospital.name from hospital";
        ?>
        <select class="textbox cbo_hospital"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['hospital_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_hospital_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select hospital.hospital_id,   hospital.name from hospital";
        ?>
        <select class="textbox cbo_hospital"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['hospital_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_patient_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select patient.patient_id,   patient.name from patient";
        ?>
        <select class="textbox cbo_patient"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['patient_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }


 function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }
}

