<?php 
class new_values{

 function new_account(  $account_category, $date_created, $profile, $username, $password, $is_online){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");$stm->execute(array(':account_id'=>0,':account_category'=>$account_category, ':date_created'=>$date_created, ':profile'=>$profile, ':username'=>$username, ':password'=>$password, ':is_online'=>$is_online
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_account_category(  $name){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into account_category values(:account_category_id, :name)");$stm->execute(array(':account_category_id'=>0,':name'=>$name
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_profile(  $dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");$stm->execute(array(':profile_id'=>0,':dob'=>$dob, ':name'=>$name, ':last_name'=>$last_name, ':gender'=>$gender, ':telephone_number'=>$telephone_number, ':email'=>$email, ':residence'=>$residence, ':image'=>$image
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_image(  $path){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into image values(:image_id, :path)");$stm->execute(array(':image_id'=>0,':path'=>$path
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_province(  ){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into province values(:province_id,)");$stm->execute(array(':province_id'=>0,
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_district(  $province){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into district values(:district_id, :province)");$stm->execute(array(':district_id'=>0,':province'=>$province
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_Hospital(  $district, $name){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into Hospital values(:Hospital_id, :district,  :name)");$stm->execute(array(':Hospital_id'=>0,':district'=>$district, ':name'=>$name
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_hospital_users(  $hospital, $account){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into hospital_users values(:hospital_users_id, :hospital,  :account)");$stm->execute(array(':hospital_users_id'=>0,':hospital'=>$hospital, ':account'=>$account
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_patient(  $account, $insurance, $description, $entry_date, $User){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into patient values(:patient_id, :account,  :insurance,  :description,  :entry_date,  :User)");$stm->execute(array(':patient_id'=>0,':account'=>$account, ':insurance'=>$insurance, ':description'=>$description, ':entry_date'=>$entry_date, ':User'=>$User
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_Treatment(  $hospital, $patient, $entry_date, $User){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into Treatment values(:Treatment_id, :hospital,  :patient,  :entry_date,  :User)");$stm->execute(array(':Treatment_id'=>0,':hospital'=>$hospital, ':patient'=>$patient, ':entry_date'=>$entry_date, ':User'=>$User
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

}

 } 
