
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account_category`     int(11)   
,`date_created`     Date 
, `profile`     int(11)   
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`is_online`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`dob`     Date 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`telephone_number`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`residence`     VARCHAR(60) 
, `image`     int(11)   

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id`     int(11) NOT NULL AUTO_INCREMENT 
,`path`     VARCHAR(60) 

,PRIMARY KEY (`image_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `province`
--

CREATE TABLE IF NOT EXISTS `province` (
`province_id`     int(11) NOT NULL AUTO_INCREMENT 

,PRIMARY KEY (`province_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `district`
--

CREATE TABLE IF NOT EXISTS `district` (
`district_id`     int(11) NOT NULL AUTO_INCREMENT 
, `province`     int(11)   

,PRIMARY KEY (`district_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `Hospital`
--

CREATE TABLE IF NOT EXISTS `Hospital` (
`Hospital_id`     int(11) NOT NULL AUTO_INCREMENT 
, `district`     int(11)   
,`name`     VARCHAR(60) 

,PRIMARY KEY (`Hospital_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `hospital_users`
--

CREATE TABLE IF NOT EXISTS `hospital_users` (
`hospital_users_id`     int(11) NOT NULL AUTO_INCREMENT 
, `hospital`     int(11)   
, `account`     int(11)   

,PRIMARY KEY (`hospital_users_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
`patient_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   
,`insurance`     VARCHAR(60) 
,`description`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`patient_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `Treatment`
--

CREATE TABLE IF NOT EXISTS `Treatment` (
`Treatment_id`     int(11) NOT NULL AUTO_INCREMENT 
, `hospital`     int(11)   
, `patient`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`Treatment_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

