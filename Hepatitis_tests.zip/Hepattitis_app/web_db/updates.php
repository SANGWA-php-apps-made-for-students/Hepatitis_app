<?php

    require_once 'connection.php';

    class updates {

        function update_account($account_category, $date_created, $profile, $username, $password, $is_online, $account_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE account set 
account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
            $stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online, $account_id));
        }

        function update_account_category($name, $account_category_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
            $stmt->execute(array($name, $account_category_id));
        }

        function update_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ? WHERE profile_id=?");
            $stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id));
        }

        function update_image($path, $image_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE image set 
path= ? WHERE image_id=?");
            $stmt->execute(array($path, $image_id));
        }

        function update_province($province_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE province set 
 WHERE province_id=?");
            $stmt->execute(array($province_id));
        }

        function update_district($province, $district_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE district set 
province= ? WHERE district_id=?");
            $stmt->execute(array($province, $district_id));
        }

        function update_Hospital($district, $name, $Hospital_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE Hospital set 
district= ?, name= ? WHERE Hospital_id=?");
            $stmt->execute(array($district, $name, $Hospital_id));
        }

        function update_hospital_users($hospital, $account, $hospital_users_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE hospital_users set 
hospital= ?, account= ? WHERE hospital_users_id=?");
            $stmt->execute(array($hospital, $account, $hospital_users_id));
        }

        function update_patient($account, $insurance, $description, $entry_date, $User, $patient_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE patient set 
account= ?, insurance= ?, description= ?, entry_date= ?, User= ? WHERE patient_id=?");
            $stmt->execute(array($account, $insurance, $description, $entry_date, $User, $patient_id));
        }

        function update_Treatment($hospital, $patient, $entry_date, $User, $Treatment_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE Treatment set 
hospital= ?, patient= ?, entry_date= ?, User= ? WHERE Treatment_id=?");
            $stmt->execute(array($hospital, $patient, $entry_date, $User, $Treatment_id));
        }

    }
    