<div class="parts  full_center_two_h heit_free margin_free home_header ">    
    <div class="parts  no_paddin_shade_no_Border xxx_titles">
        Hepatitis
    </div>
</div>  
<div class="parts menu  full_center_two_h heit_free margin_free">
    <a href="new_account.php">Users</a>

    <!--<a href="new_image.php">image</a>-->
    <!--<a href="new_province.php">province</a>-->
    <a href="new_district.php">district</a>
    <a href="new_Hospital.php">Hospital</a>
    <a href="new_hospital_users.php">hospital users</a>
    <a href="new_patient.php">patient</a>
    <a href="new_Treatment.php">Treatment</a>

    <a href="../logout.php">Login</a>

</div>
<div class="parts eighty_centered top_off_x x_titles no_paddin_shade_no_Border"style="text-align: center;" >
    Hepatitis Control/ Admin Dashboard
</div>
