<div class="parts  full_center_two_h heit_free margin_free home_header">     
    <div class="parts  no_paddin_shade_no_Border xxx_titles">
        Hepatitis Control Management System
    </div>
</div>      
<div class="parts menu eighty_centered no_paddin_shade_no_Border">
    <a href="index.php">Home</a>
    <a href="aboutus.php">Medical care</a>
    <a href="aboutus.php">About us</a>

    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="login.php">Login</a>
    </div>
</div>
