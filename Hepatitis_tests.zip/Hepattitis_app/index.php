<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>  <meta name="viewport" content="width=device-width, initial scale=1.0"/>    

        <style>
            .home_pic1{
                width: 33%;
                height: 400px;
                background-image: url('web_images/home_bg.png');
                background-repeat: no-repeat;
                background-size: 97%;
            }
            .home_text_holder{
                width: 60%;
                height: 400px;
            }
            .text1{
                background-image: url('web_images/home_left_text.png');
                background-repeat: no-repeat;
                background-size: 90%;
            }
            .text2{
                margin-top: 130px;
                font-family: century gothic;
                font-size: 16px;
            }
            .text3{
                width: 60%;
            }
        </style>
    </head>
    <body>
        <?php
            include 'header_menu.php';
        ?>

        <div id="fb-root"></div>
        <script>(function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>        

        <div class="parts full_center_two_h x_height_4x margin_free no_paddin_shade_no_Border">
            <div class="parts push_right home_pic1 margin_free">

            </div> 

            <div class="parts push_right home_text_holder no_paddin_shade_no_Border">
                <div class="parts push_right home_texts full_center_two_h text1 ">
                    <div class="parts  home_texts text2 full_center_two_h heit_free no_paddin_shade_no_Border">
                        Getting tested early staying healthy longer
                    </div>
                </div>

                <div class="parts push_right home_texts text3">
                    Hepatitis is a word not a sentence
                </div>
            </div>
        </div>
        <div class="parts eighty_centered footer">
            Copyrights <?php echo date("Y"); ?>
            <div class="fb-share-button" data-href="https://www.codeguru-pro.net" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.codeguru-pro.net%2Ftests%2Findex.php&amp;src=sdkpreparse">Share</a></div>        </div>    </body>
</html>
